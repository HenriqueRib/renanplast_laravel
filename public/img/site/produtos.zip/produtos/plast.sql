-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 15-Set-2022 às 21:20
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `plast`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `fotos`
--

CREATE TABLE `fotos` (
  `id` int(10) UNSIGNED NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `foto_produtos`
--

CREATE TABLE `foto_produtos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_produto` int(11) DEFAULT NULL,
  `imagem_produto` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `foto_produtos`
--

INSERT INTO `foto_produtos` (`id`, `id_produto`, `imagem_produto`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, '/uploads/produtos/2/235Group 6.png', '2022-09-12 19:00:46', '2022-09-13 13:15:03', '2022-09-13 13:15:03'),
(2, 2, '/uploads/produtos/2/355antarctica269.png', '2022-09-12 19:00:46', '2022-09-13 13:15:03', '2022-09-13 13:15:03'),
(3, 2, '/uploads/produtos/2/313super_g.png', '2022-09-12 19:00:46', '2022-09-13 13:15:03', '2022-09-13 13:15:03'),
(4, 1, '/uploads/produtos/1/251Header.png', '2022-09-13 13:15:39', '2022-09-13 13:15:39', NULL),
(5, 1, '/uploads/produtos/1/374papel_toalha_piccola_2rolos.png', '2022-09-13 13:15:39', '2022-09-13 13:15:39', NULL),
(6, 1, '/uploads/produtos/1/440lava_roupas_urca.png', '2022-09-13 13:15:39', '2022-09-13 13:15:39', NULL),
(7, 1, '/uploads/produtos/1/199apple.png', '2022-09-13 13:15:39', '2022-09-13 13:15:39', NULL),
(8, 1, '/uploads/produtos/1/793super_g.png', '2022-09-13 13:15:39', '2022-09-13 13:15:39', NULL),
(9, 1, '/uploads/produtos/1/584apple.png', '2022-09-13 13:15:39', '2022-09-13 13:27:28', '2022-09-13 13:27:28'),
(10, 1, '/uploads/produtos/1/615logo.png', '2022-09-13 13:15:39', '2022-09-13 13:15:39', NULL),
(11, 1, '/uploads/produtos/1/452Group 6.png', '2022-09-13 13:15:39', '2022-09-13 13:15:39', NULL),
(12, 1, '/uploads/produtos/1/462antarctica269.png', '2022-09-13 13:15:39', '2022-09-15 16:23:21', '2022-09-15 16:23:21'),
(13, 3, '/uploads/produtos/3/102papel_toalha_piccola_2rolos.png', '2022-09-13 13:18:47', '2022-09-13 13:18:47', NULL),
(14, 3, '/uploads/produtos/3/794lava_roupas_urca.png', '2022-09-13 13:18:47', '2022-09-13 13:18:47', NULL),
(15, 3, '/uploads/produtos/3/287apple.png', '2022-09-13 13:18:47', '2022-09-13 13:18:47', NULL),
(16, 5, '/uploads/produtos/5/970lava_roupas_urca.png', '2022-09-13 13:24:08', '2022-09-13 13:24:08', NULL),
(17, 5, '/uploads/produtos/5/14apple.png', '2022-09-13 13:24:08', '2022-09-13 13:24:08', NULL),
(18, 5, '/uploads/produtos/5/688capa_2.jpg', '2022-09-13 13:24:08', '2022-09-13 13:24:08', NULL),
(19, 6, '/uploads/produtos/6/913Header.png', '2022-09-13 13:32:46', '2022-09-13 13:32:46', NULL),
(20, 6, '/uploads/produtos/6/585papel_toalha_piccola_2rolos.png', '2022-09-13 13:32:46', '2022-09-13 21:26:23', '2022-09-13 21:26:23'),
(21, 6, '/uploads/produtos/6/968lava_roupas_urca.png', '2022-09-13 13:32:46', '2022-09-13 13:32:46', NULL),
(22, 8, '/uploads/produtos/8/1851.png', '2022-09-15 15:15:24', '2022-09-15 15:15:24', NULL),
(23, 8, '/uploads/produtos/8/3042.png', '2022-09-15 15:15:24', '2022-09-15 15:15:24', NULL),
(24, 8, '/uploads/produtos/8/7503.jpg', '2022-09-15 15:15:24', '2022-09-15 15:15:24', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(10, '2014_10_12_000000_create_users_table', 1),
(11, '2014_10_12_100000_create_password_resets_table', 1),
(12, '2019_08_19_000000_create_failed_jobs_table', 1),
(13, '2021_01_08_201345_create_posts_table', 1),
(14, '2021_01_11_182445_create_fotos_table', 1),
(15, '2021_01_11_184023_create_fotos_date_table', 1),
(16, '2021_12_10_170116_add_column_categoria_to_posts_table', 1),
(17, '2021_12_17_173908_add_column_created_delete_to_users_table', 1),
(18, '2021_12_23_124858_add_column_image_to_users_table', 1),
(23, '2022_09_06_101812_create_produtos_table', 2),
(24, '2022_09_06_101836_create_foto_produtos_table', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `txt` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `categoria` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modo` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medidas` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lote` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serie` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preco` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estoque` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cores` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacao` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `view` int(11) DEFAULT 0,
  `principal` int(11) DEFAULT 0 COMMENT '0-Não,1-Sim',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `descricao`, `modo`, `medidas`, `lote`, `serie`, `preco`, `estoque`, `ativo`, `cores`, `observacao`, `image`, `view`, `principal`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'teste 1', 'ijisjiasji', 'ijasijiaj', 'isajijsaiji', 'jijasijaij', 'jijasisjaij', 'ijiasjiaji', 'Não', 'Sim', 'Rosa', NULL, '/uploads/produtos/1/4antarctica269.png', 0, 1, '2022-09-12 18:51:16', '2022-09-15 16:27:31', NULL),
(2, 'Teste 2', 'ijsaiasjiaj', 'jasijasij', 'ijsaijasij', 'ijsaijai', 'ijsaiji', 'ijiji', 'Sim', 'Sim', '[\"Azul\"]', NULL, '/uploads/produtos/2/393super_g.png', 0, 0, '2022-09-12 19:00:46', '2022-09-13 13:15:03', '2022-09-13 13:15:03'),
(3, 'Produto 2', 'carro', 'carro', 'carro', '1', '1', '1', 'Sim', 'Sim', '[\"Azul\"]', NULL, '/uploads/produtos/3/785Header.png', 0, 1, '2022-09-13 13:18:47', '2022-09-15 15:00:11', NULL),
(4, 'Produto 3', 'Moto', 'moto', 'moro', '1', '1', '1', 'Sim', 'Sim', 'Sem cor', NULL, '/uploads/produtos/4/322papel_toalha_piccola_2rolos.png', 0, 0, '2022-09-13 13:19:23', '2022-09-13 13:33:02', '2022-09-13 13:33:02'),
(5, 'Produto 4', 'nootbook', 'nootbook', 'nootbook', '2', '2', '2', 'Sim', 'Sim', '[\"Sem cor\"]', NULL, '/uploads/produtos/5/676capa_1.jpg', 0, 1, '2022-09-13 13:24:08', '2022-09-15 14:59:48', NULL),
(6, 'teste 1 2', 'iasuash', 'uashuashu', 'hsauhasu', 'uashu', 'hasuhsa', 'uhushu', 'Sim', 'Sim', '[\"[\\\"[\\\\\\\"[\\\\\\\\\\\\\\\"Sem cor\\\\\\\\\\\\\\\"]\\\\\\\"]\\\"]\"]', NULL, '/uploads/produtos/6/519lava_roupas_urca.png', 0, 1, '2022-09-13 13:32:46', '2022-09-15 15:24:34', NULL),
(7, 'Filtro Principal', 'uhsauasuh', 'asuhaushu', 'uashsauh', 'uashuahu', 'uhuashu', 'uhaushu', 'Não', 'Sim', 'Sem cor', NULL, '/uploads/produtos/7/6091.png', 0, 1, '2022-09-13 21:25:39', '2022-09-15 16:27:03', NULL),
(8, 'Henrique Ribeiro Moreira', 'Os baixos nunca chegaram tão alto.\r\nO driver dinâmico criado pela Apple vem com amplificador personalizado e renderiza as músicas em uma riqueza absurda de detalhes. Seus ouvidos vão perceber mais profundidade nos graves e os agudos mais cristalinos.', NULL, NULL, 'asa', 'iji', 'hau', 'Sim', 'Sim', 'Branco', NULL, '/uploads/produtos/8/8321.png', 0, 1, '2022-09-15 15:15:24', '2022-09-15 15:15:24', NULL),
(9, 'carro', 'asas', 'asas', NULL, 'asa', 'as', 'as', 'Sim', 'Sim', 'Sem cor', NULL, '/uploads/produtos/9/3076.jpg', 0, 1, '2022-09-15 15:27:13', '2022-09-15 20:05:34', NULL),
(10, 'Nissan Skyline', 'asasa', NULL, NULL, 'asa', 'asa', 'asa', 'Sim', 'Sim', 'Branco', NULL, '/uploads/produtos/10/721placa.jpeg', 0, 1, '2022-09-15 15:27:54', '2022-09-15 15:27:54', NULL),
(11, 'Empresa 1', 'asasa', NULL, NULL, 'ashuhasu', 'hu', 'hu', 'Sim', 'Sim', 'Dorado', NULL, '/uploads/produtos/11/741.png', 0, 1, '2022-09-15 15:28:34', '2022-09-15 15:28:34', NULL),
(12, 'Henriqueasassss1', 'asas', NULL, NULL, 'asa', '1515', '15151', 'Sim', 'Sim', 'Sem cor', NULL, '/uploads/produtos/12/375agulha_esmirna_circulo_158_1_20201213214601.jpeg', 0, 1, '2022-09-15 15:29:04', '2022-09-15 18:07:21', NULL),
(13, 'carrosssss', 'sasasasas', NULL, NULL, 'asas', 'asas', 'asas', 'Não', 'Sim', 'Sem cor', NULL, '/uploads/produtos/13/1891.png', 0, 0, '2022-09-15 18:07:53', '2022-09-15 18:07:53', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int(11) DEFAULT 0,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `level`, `email`, `email_verified_at`, `password`, `banner_image`, `image`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 'Henrique Ribeiro Moreira', 1, 'admin@hoomweb.com', '2022-08-29 22:34:05', '$2y$10$TgfSxEKuB0o5gPS1JDLoj.20yME4P7bq6YNrUHHRA8tUQEk6Zo0W.', NULL, NULL, NULL, '2022-08-29 22:34:05', '2022-08-29 22:34:05', NULL),
(5, 'Teste', 1, 'teste1@gmail.com', '2022-08-29 22:47:23', '$2y$10$p7HC3oU4lI3gsBKlxVb/Te5rjbWsY1pnbt3dVvNlHyubhKwWaRq9.', NULL, NULL, NULL, '2022-08-29 22:47:23', '2022-08-29 22:48:15', NULL),
(6, 'Henrique Ribeiro Moreira 2', 1, 'ribeiro.henriquem@gmail.com2', '2022-08-29 22:48:30', '$2y$10$gJEl/D4bGdVIKghnNTK.Re54O4TXdpe1rrQhdmTLXY4zkHksWh2QK', NULL, NULL, NULL, '2022-08-29 22:48:30', '2022-08-29 22:49:19', '2022-08-29 22:49:19'),
(7, 'arboriza', 0, 'arbo@gmail.com', '2022-09-06 14:49:42', '$2y$10$wVtj9u00Xtk5/AfGRHbcoOtkxzmldePh0QGiV6ho.Ftc4tup4TYg6', NULL, NULL, NULL, '2022-09-06 14:49:42', '2022-09-06 14:49:42', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Índices para tabela `fotos`
--
ALTER TABLE `fotos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `foto_produtos`
--
ALTER TABLE `foto_produtos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Índices para tabela `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `fotos`
--
ALTER TABLE `fotos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `foto_produtos`
--
ALTER TABLE `foto_produtos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
